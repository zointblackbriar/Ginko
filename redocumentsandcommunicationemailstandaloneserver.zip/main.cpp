/* 
 * File:   main.cpp
 * Author: user
 *
 * Created on March 11, 2013, 3:57 PM
 */

/* standard c++ headers*/
#include <cstdlib>
#include <iostream>
#include <memory>
#include <string>
#include <stdexcept>
#include <sstream>
#include <ctype.h>
#include <math.h>

/* network related stuff */

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <time.h> 

/* MySQL Connector headers */

#include <mysql_driver.h>
#include <mysql_connection.h>

#include <cppconn/driver.h>
#include <cppconn/exception.h>
#include <cppconn/resultset.h>
#include <cppconn/statement.h>
#include <cppconn/prepared_statement.h>

#include "ginko.h"
#include "defines.h"

CMySQLData::CMySQLData () {
	host = DBHOST;
	user = USER;
	password = PASSWORD;
	database = DB;
	area = "none";
	plugtype = "none";
	ipv4 = "none";
	latitude = 0;
	longitude = 0;
}

int CMySQLData::CMySQLConnect() {
	try {
		driver = get_driver_instance();
		con = driver->connect(host, user, password);
		return 0;
	} catch(sql::SQLException &e) {
		if(e.getErrorCode() != 0) {
			sqlerrornotifier(__FILE__,__FUNCTION__,__LINE__,e.what(), e.getErrorCode(),e.getSQLState());
		}
		return -1;
	}	
} 

void CMySQLData::CGetSiteByGPS (float rem_lat, float rem_long, std::string rem_plug) {
	latitude = rem_lat;
	longitude = rem_long;
	plugtype = rem_plug;
	
	sql::Statement *stmt;
	sql::ResultSet *res;

	float fl_lo_min, fl_lo_max, fl_la_min, fl_la_max, fl_dif_lat, fl_dif_lon, fl_dist;
	float Radius = 6378; // Sphere of Earth in m
	float distance = 300; // Radius, to limit search, 100 ~ 3.5km
	float min_dist = 6400;
	
	std::string res_tmp, res_lo, res_la;
	std::stringstream query;
	
	fl_dif_lat = distance / Radius;
	fl_la_min = latitude - fl_dif_lat;
	fl_la_max = latitude + fl_dif_lat;
	
	fl_dif_lon = distance / (Radius * cos (PI * latitude / 180));
	fl_lo_min = longitude - fl_dif_lon;
	fl_lo_max = longitude + fl_dif_lon;			
		
	std::cout << "latitude min / max: " << fl_la_min << " / " << fl_la_max << std::endl;
	std::cout << "longitude min / max: " << fl_lo_min << " / " << fl_lo_max << std::endl;
	
	try {
		con->setSchema(database);
		stmt = con->createStatement();
	
		/*<
		 * select * from siteloc, ipaddr, freeplugs, plugtypes 
		 * where 
		 * siteloc.ipaddr = ipaddr.ID 
		 * and 
		 * siteloc.ID = freeplugs.siteloc 
		 * and 
		 * freeplugs.plugtype = plugtypes.ID 
		 * and 
		 * freeplugs.free >= 2 
		 * and 
		 * (siteloc.longitude >= 12.9142 and siteloc.longitude <= 12.9392) 
		 * and 
		 * (siteloc.latitude >= 50.8208 and siteloc.latitude <= 50.8458) 
		 */
		
		query << "SELECT * FROM " << SL << ", " << IP << ", " << FP << ", " << PT
					<< " WHERE "
					<< SL << "." << SLIP << " = " << IP << "." << IPID
					<< " AND "
					<< SL << "." << SLID << " = " << FP << "." << FPSL
					<< " AND " 
					<< FP << "." << FPPT << " = " << PT << "." << PTID
					<< " AND "
					<< FP << "." << FPFR << " >= " << "2"
					<< " AND "
					<< "("
						<< SL << "." << SLLO << " >= " << FloatToString(fl_lo_min)
						<< " AND "
						<< SL << "." << SLLO << " <= " << FloatToString(fl_lo_max)
					<< ")"
					<< " AND "
					<< "("
						<< SL << "." << SLLA << " >= " << FloatToString(fl_la_min)
						<< " AND "
						<< SL << "." << SLLA << " <= " << FloatToString(fl_la_max)
					<< ")";
	//		std::cout << query.str() << std::endl;
			res = stmt->executeQuery(query.str());
			query.str("");
		
		if (res->rowsCount()) {
	/*		std::cout << SLID << "\t" 
								<< SLLO << "\t" 
								<< SLLA << "\t" 
								<< SLSN << "\t\t\t" 
								<< SLCT << "\t\t" 
								<< IPV4 << "\t" 
								<< FPFR << "\t" 
								<< PTNA << "\t" 
								<< "Distance to " << str_longitude << " / " << str_latitude << std::endl;*/
			while (res->next()) {
				res_lo = "";
				res_la = "";
				res_tmp = "";
				res_lo = res->getString(SLLO);
				res_la = res->getString(SLLA);
				res_tmp = res->getString(IPV4);
				fl_dist = calc_gps_distance(latitude,longitude,stringtofloat(res_la),stringtofloat(res_lo));
				
	/*			std::cout << res->getString(SLID) << "\t" 
									<< res->getString(SLLO) << "\t\t"
									<< res->getString(SLLA) << "\t\t" 
									<< res->getString(SLSN)	<< "    \t" 
									<< res->getString(SLCT) << "    \t" 
									<< res->getString(IPV4) << "\t" 
									<< res->getString(FPFR) << "\t" 
									<< res->getString(PTNA) << "\t" 
									<< fl_dist << std::endl; */
				if (fl_dist < min_dist) {
					ipv4 = "";
					ipv4 = res_tmp;
					min_dist = fl_dist;		
				}
			}
		}
			
		std::cout << "IP of nearest Site: " << ipv4 << std::endl;
		delete res;
		delete stmt;
		
	} catch(sql::SQLException& e) {
			if(e.getErrorCode() != 0) {
				sqlerrornotifier(__FILE__,__FUNCTION__,__LINE__,e.what(), e.getErrorCode(),e.getSQLState());
			}
	}	
};

CMySQLData::~CMySQLData () {
	delete con;
};

int main() {

	CMySQLData MySQLdata;
	
	int listenfd = 0, connfd = 0;
	struct sockaddr_in serv_addr; 

	char sendBuff[1025];
	char recvBuff[1025];
	ssize_t bytes_recieved;
	time_t ticks; 

	listenfd = socket(AF_INET, SOCK_STREAM, 0);
	memset(&serv_addr, '0', sizeof(serv_addr));
	memset(sendBuff, '0', sizeof(sendBuff)); 

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons(5000); 

	bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr)); 

	listen(listenfd, 10); 

	while(1)
	{
		std::cout << "Waiting for connection" << std::endl;
		connfd = accept(listenfd, (struct sockaddr*)NULL, NULL); 

		bytes_recieved = recv(connfd, recvBuff, 1025, 0);

		std::cout << "Bytes recieved: " << bytes_recieved << std::endl;
		recvBuff[bytes_recieved] = '\0';
		std::cout << "Data: " << recvBuff << std::endl;

		MySQLdata.CMySQLConnect();

	/*    ticks = time(NULL);
			snprintf(sendBuff, sizeof(sendBuff), "%.24s\r\n", ctime(&ticks));
			write(connfd, sendBuff, strlen(sendBuff)); */

			close(connfd);
			sleep(1);
	 }

}

