/* 
 * File:   defines.h
 * Author: user
 *
 * Created on March 27, 2013, 1:35 PM
 */

#ifndef DEFINES_H
#define	DEFINES_H

/* global defines */ 

#define DBHOST "localhost"
#define USER "root"
#define PASSWORD "root"

#define NUMOFFSET 100
#define COLNAME 200

#define VERBOSE 1

#define BACKSPACE 127
#define RETURN 10
#define PI 3.14159265

#define DB "appdb"

// Table siteloc
#define SL "siteloc"
#define SLID "ID_sl" // ID - Auto Increment
#define SLIP "ipaddr" // Reference to corresponding ID from ipaddr
#define SLLO "longitude" 
#define SLLA "latitude"
#define SLAL "altitude"
#define SLSN "sitename"
#define SLST "street"
#define SLPO "postal"
#define SLCT "city"

// Table plugtypes 
#define PT "plugtypes"
#define PTID "ID_pl" // ID - Auto Increment
#define PTNA "name" // Name of the Plug

// Table ipaddr
#define IP "ipaddr"
#define IPID "ID_ip" // ID - Auto Increment
#define IPV4 "v4" 
#define IPV6 "v6"

// Table freeplugs
#define FP "freeplugs"
#define FPID "ID_frpl" // ID - Auto Increment
#define FPSL "siteloc" // Reference to corresponding ID from siteloc
#define FPFR "free"
#define FPPT "plugtype" // Reference to corresponding ID from plugtypes




#endif	/* DEFINES_H */

